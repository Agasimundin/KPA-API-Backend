from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from app import models
from app.database import engine, get_db
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

# Create database tables (if not already created)
models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# Pydantic schema for request and response
class FormDataRequest(BaseModel):
    bogie_number: str
    coach_type: str
    remarks: Optional[str] = None

class FormDataResponse(FormDataRequest):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True

# POST /add_form_data
@app.post("/add_form_data", response_model=FormDataResponse)
def add_form_data(form_data: FormDataRequest, db: Session = Depends(get_db)):
    db_data = models.FormData(
        bogie_number=form_data.bogie_number,
        coach_type=form_data.coach_type,
        remarks=form_data.remarks
    )
    db.add(db_data)
    db.commit()
    db.refresh(db_data)
    return db_data

# GET /get_form_data_by_id/{id}
@app.get("/get_form_data_by_id/{id}", response_model=FormDataResponse)
def get_form_data_by_id(id: int, db: Session = Depends(get_db)):
    data = db.query(models.FormData).filter(models.FormData.id == id).first()
    if not data:
        raise HTTPException(status_code=404, detail="Form data not found")
    return data
