# KPA API Assignment

This project contains a FastAPI backend with two endpoints:
- `POST /add_form_data`: To add new form data
- `GET /get_form_data_by_id/{id}`: To retrieve form data by ID

## Setup Instructions

1. Create virtual environment:
   ```bash
   python -m venv venv
