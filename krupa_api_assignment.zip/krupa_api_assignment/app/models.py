from sqlalchemy import Column, Integer, String, DateTime
from app.database import Base
from datetime import datetime

class FormData(Base):
    __tablename__ = "form_data"

    id = Column(Integer, primary_key=True, index=True)
    bogie_number = Column(String, nullable=False)
    coach_type = Column(String, nullable=False)
    remarks = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
